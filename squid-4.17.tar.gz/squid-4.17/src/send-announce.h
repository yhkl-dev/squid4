/*
 * Copyright (C) 1996-2021 The Squid Software Foundation and contributors
 *
 * Squid software is distributed under GPLv2+ license and includes
 * contributions from numerous individuals and organizations.
 * Please see the COPYING and CONTRIBUTORS files for details.
 */

/* DEBUG: section 27    Cache Announcer */

#ifndef SQUID_SEND_ANNOUNCE_H_
#define SQUID_SEND_ANNOUNCE_H_

void start_announce(void *unused);

#endif /* SQUID_SEND_ANNOUNCE_H_ */

